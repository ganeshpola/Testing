sap.ui.define(['jquery.sap.global'],
	function(jQuery) {
		"use strict";
		var persocode = {
			oData: {
				

				_persoSchemaVersion: "1.0",
				aColumn: [{
					id: "demo-Table-Column1",
					order: "0",
					text: "EmpId",
					property: "EmpId",
					visible: true
				}, {
					id: "demo-Table-Column2",
					order: "1",
					text: "Firstname",
					visible: true
				}, {
					id: "demo-Table-Column3",
					order: "2",
					text: "Designation",
					visible: true
				}, {
					id: "demo-Table-Column4",
					order: "3",
					text: "Location",
					visible: true
				}, {
					id: "demo-Table-Column5",
					order: "4",
					text: "Department",
					visible: true
				},
				{
					id: "demo-Table-Column6",
					order: "5",
					text: "Experience",
					visible: true
					},
					{
					id: "demo-Table-Column7",
					order: "5",
					text: "Experience",
					visible: true
				},{
					id: "demo-Table-Column8",
					order: "6",
					text: "Joiningdate",
					visible: true
				},{
						id: "demo-Table-Column9",
					order: "7",
					text: "Email",
					visible: true
				},{
					id: "demo-Table-Column10",
					order: "8",
					text: "Phonenumber",
					visible: true
				},{
					id: "demo-Table-Column11",
					order: "9",
					text: "Dob",
					visible: true
				}]
			},
			getPersData: function() {
				var oDeferred = new jQuery.Deferred();
				if (!this._oBundle) {
					this._oBundle = this.Data;
				}
				var oBundle = this._oBundle;
				oDeferred.resolve(oBundle);
				return oDeferred.promise();
			},
			setPersData: function(oBundle) {
				var oDeferred = new jQuery.Deferred();
				this._oBundle = oBundle;
				oDeferred.resolve();
				return oDeferred.promise();
			},
			resetPersData: function() {
					var oDeferred = new jQuery.Deferred();
					var oInitialData = {
						_persoSchemaVersion: "1.0",
						aColumns: [{
							id: "demo-Table-Column1",
							order: 0,
							text: "Empno",
							property: "Empno",
							visible: true
						}, {
							id: "demo-Table-Column2",
							order: 1,
							text: "Empname",
							visible: true
						}, {
							id: "demo-Table-Column3",
							order: 2,
							text: "Street",
							visible: true
						}, {
							
							
							
							id: "demo-Table-Column4",
							order: 3,
							text: "City",
							visible: true
						}, {
							id: "demo-Table-Column5",
							order: 4,
							text: "Postalcode",
							visible: true
						}, {
							id: "demo-Table-Column6",
							order: 4,
							text: "Country",
							visible: true
						}]
					};
					this._oBundle = oInitialData;

					oDeferred.resolve();
					return oDeferred.promise();
				}
				
		};

		return persocode;
	}, /* bExport= */ true);