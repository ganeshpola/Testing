sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/TablePersoController",
	"jquery.sap.global",
	"../model/persocode",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/export/Spreadsheet"
], function(Controller, JSONModel, Filter, FilterOperator, TablePersoController, jquery, persocode, Export, ExportTypeCSV, Spreadsheet) {
	"use strict";

	return Controller.extend("ASSESSMENTASSESSMENT.controller.View1", {
		onInit: function() {
			var location = new JSONModel({
				LocationVal: "",
				inpVAl: ""
			});
			this.getView().setModel(location, "location");
			// 	var inpModel = new JSONModel({

			// 	inpMod:""
			// });
			// this.getView().setModel(inpModel,"INPModel");

			this.ComboBox();
			this.Select();
			this.fresh();
			this.ValueHelp();
			this._oTPC = new TablePersoController({
				table: this.getView().byId("Table"),

				componentName: "demo",
				persoService: persocode

			}).activate();

		},
		OnRefresh: function() {
			// this.fresh();
			this.getView().byId("InputId").setValue(null);
			this.getView().byId("ComboId").setValue(null);
			this.getView().byId("Select").setValue(null);
			this.getView().byId("ValueId").setValue(null);
			this.fresh();

		},
		ComboBox: function() {
			var oModel2 = new JSONModel({
				designVal: ""
			});
			this.getView().setModel(oModel2, "ComboBox");
			var odata = this.getOwnerComponent().getModel();
			var oNewFilter = [new Filter("Flag", FilterOperator.EQ, "D")];
			odata.read("/EmployeeSearchHelpSet", {
				filters: oNewFilter,
				success: function(oodata) {
					console.log(oodata);
					oModel2.setData({
						"EmployeeSearchHelpSet": oodata.results
					});
				}
			});
		},
		Select: function() {
			var oModel3 = new JSONModel();
			this.getView().setModel(oModel3, "SelectBox");
			var odata = this.getOwnerComponent().getModel();
			var oNewFilter = [new Filter("Flag", FilterOperator.EQ, "L")];
			odata.read("/EmployeeSearchHelpSet", {
				filters: oNewFilter,
				success: function(data) {
					// console.log(data);
					oModel3.setData({
						"EmployeeSearchHelpSet": data.results
					});
				},
				error: function() {

				}
			});
		},
		SelectChange: function(oEvent) {
			var select = oEvent.getSource().getSelectedItem().getText();
			this.getView().getModel("location").setProperty("/LocationVal", select);
		},
		Onsearch: function() {
			var that = this;
			var oFilter = [];
			// var Inpudata = that.getView().byId("InputId").getValue();
			var Inpudata = that.getView().getModel("location").getProperty("/inpVAl");
			if (Inpudata.length > 0) {
				oFilter.push(new Filter("Firstname", FilterOperator.Contains, Inpudata));
			}
			var ComboData = that.getView().byId("ComboId").getValue();
			var SelectData = that.getView().getModel("location").getProperty("/LocationVal");
			var Valuedata = that.getView().byId("ValueId").getValue();

			oFilter.push(new Filter("Designation", FilterOperator.Contains, ComboData));
			oFilter.push(new Filter("Location", FilterOperator.Contains, SelectData));
			oFilter.push(new Filter("Department", FilterOperator.Contains, Valuedata));

			var odata = that.getOwnerComponent().getModel();
			odata.read("/Employee_DetailsSet", {
				filters: [oFilter],
				and: true,
				success: function(oData) {
					that.getView().getModel("TableModel").setData({
						"Employee_DetailsSet": oData.results
					});
				}
			});
		},
		onLiveChange: function(oEvent) {
			var selInp = oEvent.getSource().getValue();
			var Inpudat = this.getView().getModel("location").setProperty("/inpVAl", selInp);
		},
		fresh: function() {
			var oModel = new JSONModel();
			this.getView().setModel(oModel, "TableModel");
			var FModel = new JSONModel();
			this.getView().setModel(FModel, "FormModel");

			var odata = this.getOwnerComponent().getModel();
			odata.read("/Employee_DetailsSet", {
				success: function(data) {
					oModel.setData({
						"Employee_DetailsSet": data.results
					});
				}
			});
			var model = new JSONModel({
				editable: false,
				editVsblBtn: true,
				closeVsblBtn: true,
				saveVsblBtn: true,
				cancelvsblbtn: true
			});
			this.getView().setModel(model, "ViewModel");
		},
		ValueHelpData: function() {
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("ASSESSMENTASSESSMENT.view.FragmentTwo", this);
				this.getView().addDependent(this.oDialog);
			}
			this.oDialog.open();
		},
		Valuecancel: function() {
			this.oDialog.close();
		},
		ValueHelp: function() {
			var oValue = new JSONModel();
			this.getView().setModel(oValue, "ValueHelp");
			var odata = this.getOwnerComponent().getModel();
			var oNewFilter = [new Filter("Flag", FilterOperator.EQ, "DP")];
			odata.read("/EmployeeSearchHelpSet", {
				filters: oNewFilter,
				success: function(data) {
					// console.log(data);
					oValue.setData({
						"EmployeeSearchHelpSet": data.results
					});
				},
				error: function() {

				}
			});

		},
		ValueHelpPress: function(oEvent) {
			var data = oEvent.getSource().getTitle();
			this.getView().getModel("FormModel").setProperty("/Department", data);
			// var oNewFilters = new Filter("Department", FilterOperator.EQ, data);
			this.oDialog.close();
		},
		OpenFrag: function() {
			// var that=this;
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("ASSESSMENTASSESSMENT.view.Fragment", this);
				this.getView().addDependent(this.oDialog);
			}
			this.oDialog.open();

		},
		onCreate: function() {
			var FormData = this.getView().getModel("FormModel").getData();
			var FirstName = this.getView().getModel("FormModel").getData().Firstname;
			var SecondName = this.getView().getModel("FormModel").getData().Secondname;
			var Dob = this.getView().getModel("FormModel").getData().Dob;
			var JoiningDate = this.getView().getModel("FormModel").getData().Joiningdate;
			if (FormData === undefined || FirstName === undefined || SecondName === undefined || Dob === undefined || JoiningDate === undefined) {

			} else {
				var that = this;
				var formdataa = that.getView().getModel("FormModel").getData();
				// var that = this;
				var odataModel = that.getOwnerComponent().getModel();
				odataModel.create("/Employee_DetailsSet", formdataa, {
					success: function(oData, res) {
						if (res.statusCode === "201" || res.statusCode === 201) {
							sap.m.MessageBox.success("Recorde Created Successfully");
						}

					},
					error: function(error) {
						var msg = JSON.parse(error.responseText).error.message;

					}

				});
				this.fresh();
			}

			// this.oDialog.close();
			// this.oDialog.destroy();
			// this.oDialog = null;
			// var Firstname = that.getView().getModel("FormModel").getData().Firstname;
			// var Secondname = that.getView().getModel("FormModel").getData().Secondname;
			// var Joiningdate = that.getView().getModel("FormModel").getData().Joiningdate;
			// var Dob = that.getView().getModel("FormModel").getData().Dob;
			// var Reportto = that.getView().getModel("FormModel").getData().Reportto;
			// if(Firstname===undefined && Secondname===undefined && Joiningdate===undefined && Dob===undefined && Reportto===undefined){
			// 			sap.m.MessageBox.warning("Please Enter All Details");	
			// }

		},
		onCancel: function() {
			this.oDialog.close();
		},
		SearchAll: function(oEvent) {
			var source = oEvent.getSource();
			var items = source.getValue();
			var oTable = this.getView().byId("Table");
			var tableItems = oTable.getBinding("items");
			var nameFilter = new sap.ui.model.Filter("EmpId", sap.ui.model.FilterOperator.Contains, items);
			var Firstname = new sap.ui.model.Filter("Firstname", sap.ui.model.FilterOperator.Contains, items);
			var Designation = new sap.ui.model.Filter("Designation", sap.ui.model.FilterOperator.Contains, items);
			var Department = new sap.ui.model.Filter("Department", sap.ui.model.FilterOperator.Contains, items);
			var Reportto = new sap.ui.model.Filter("Reportto", sap.ui.model.FilterOperator.Contains, items);
			// var Experience = new sap.ui.model.Filter("Experience", sap.ui.model.FilterOperator.Contains, items);
			//var Joiningdate = new sap.ui.model.Filter("Joiningdate", sap.ui.model.FilterOperator.Contains, items);
			// var Email = new sap.ui.model.Filter("Email", sap.ui.model.FilterOperator.Contains, items);
			// var Phonenumber = new sap.ui.model.Filter("Phonenumber", sap.ui.model.FilterOperator.Contains, items);
			// var Dob = new sap.ui.model.Filter("Dob", sap.ui.model.FilterOperator.Contains, items);
			var filter = [nameFilter, Firstname, Designation, Department, Reportto];
			var filters = new sap.ui.model.Filter(filter, false);
			tableItems.filter(filters);
			// ,Experience,Joiningdate,Email,Phonenumber,Dob

		},
		// onDelete: function() {
		// 	// var that=this;
		// 	var Table = this.getView().byId("Table");
		// 	var selectItem = Table.getSelectedItems().EmpId;
		// 	// var tabledata = oEvent.getSource().getBindingContext("TableModel").getObject();
		// 	var odata = this.getOwnerComponent().getModel();
		// 	odata.remove("/Employee_DetailsSet('" + selectItem + "')", {
		// 		success: function(data, res) {
		// 			if (res.statusCode === "204" || res.statusCode === 204) {
		// 				sap.m.MessageBox.success("Record deleted successfully");
		// 			}
		// 		},
		// 		error: function() {

		// 		}
		// 	});

		// },
		onDelete: function(oEvent) {
			var that = this;

			var tabView = this.getView().byId("Table");

			var selectItem = tabView.getSelectedItems();

			if (selectItem.length > 0) {

				for (var i = selectItem.length - 1; i >= 0; --i) {
					var oModel = that.getOwnerComponent().getModel();
					var selectedItem = selectItem[i].getBindingContext("TableModel").getObject().EmpId;
					oModel.remove("/Employee_DetailsSet('" + selectedItem + "')", {
						success: function(data, res) {
							if (res.statusCode === "204" || res.statusCode === 204) {
								sap.m.MessageBox.success("Record Deleted Successfully");
							}
						},
						error: function(error) {
							sap.m.MessageToast.show(error);
						}
					});
				}
				this.fresh();

			} else {
				sap.m.MessageBox.warning(" Select One Row");
			}

		},
		Navigation: function(oEvent) {
			var TableObject = oEvent.getSource().getBindingContext("TableModel").getObject().EmpId;
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("View2", {
				Record: TableObject
			});
		},
		onPersoButtonPressed: function(oEvent) {
			var that = this;
			that._oTPC.openDialog();
		},
		onTablePersoRefresh: function() {
			var that = this;
			// DemoPersoService.resetPersData();
			that._oTPC.refresh();
		},
		onExit: function() {
			var that = this;
			that._oTPC.destroy();
		},
		oExport: function(oEvent) {

			var oExport = new Export({

				// Type that will be used to generate the content. Own ExportType's can be created to support other formats
				exportType: new ExportTypeCSV({
					separator: "Column"
				}),

				// Pass in the model created above
				models: this.getView().getModel("TableModel"),

				// binding information for the rows aggregation
				rows: {
					path: "/Employee_DetailsSet"
				},

				// column definitions with column name and binding info for the content

				columns: [{
						name: "EmpId",
						template: {
							content: "{EmpId}"
						}
					}, {
						name: "Firstname",
						template: {
							content: "{Firstname}"
						}
					}, {
						name: "Designation",
						template: {
							content: "{Designation}"
						}
					}, {
						name: "Location",
						template: {
							content: "{Location}"
						}
					}, {
						name: "Department",
						template: {
							content: "{Department}"
						}
					}, {
						name: "Reportto",
						template: {
							content: "{Reportto}"
						}
					}, {
						name: "Experience",
						template: {
							content: "{Experience}"
						}
					}, {
						name: "Joiningdate",
						template: {
							content: "{Joiningdate}"
						}
					}, {
						name: "Email",
						template: {
							content: "{Email}"
						}
					}, {
						name: "Phonenumber",
						template: {
							content: "{Phonenumber}"
						}
					}, {
						name: "Dob",
						template: {
							content: "{Dob}"
						}
					}

				]
			});

			// download exported file
			oExport.saveFile().catch(function(oError) {
				// MessageBox.error("Error when downloading data. Browser might not be supported!\n\n" + oError);
			}).then(function() {
				oExport.destroy();
			});
		},
		createColumnConfig: function() {
			var aCols = [];

			aCols.push({
				label: 'emp_id',
				property: ['EmpId']

			});

			aCols.push({
				label: 'Emp Name',
				property: 'Firstname'

			});

			aCols.push({
				label: 'Desgnation',
				property: 'Designation'

			});
			aCols.push({
				label: 'Location',
				property: 'Location'

			});

			aCols.push({
				label: 'Department',
				property: 'Department'

			});

			aCols.push({
				label: 'Reporting To',
				property: 'Reportto'

			});

			aCols.push({
				label: 'Experice',
				property: 'Experience'

			});
			aCols.push({
				label: 'Joining date',
				property: 'Joiningdate'

			});
			aCols.push({
				label: 'Email',
				property: 'Email'

			});
			aCols.push({
				label: 'Phone no',
				property: 'Phonenumber'

			});
			aCols.push({
				label: 'Dob',
				property: 'Dob'

			});

			return aCols;
		},
		OnExcel: function() {
			var that = this;
			var TableData = that.getView().byId("Table");
			var TableItems = TableData.getItems();
			if (TableItems.length > 0) {
				var aCols = that.createColumnConfig();
				var Collectionrecord = that.getView().getModel("TableModel").getData().Employee_DetailsSet;

				var oSettings = {
					workbook: {
						columns: aCols,
						context: {
							sheetName: "Employee Details List"
						}
					},
					dataSource: Collectionrecord,
					fileName: "Employee Details List"
				};
				var oSheet = new Spreadsheet(oSettings);
				oSheet.build()
					.then(function() {

					})
					.finally(function() {
						oSheet.destory();
					});

			}

		},
		DateChanger: function() {
			this.getView().getModel("ViewModel").setProperty("/editable", true);
		}
	});
});