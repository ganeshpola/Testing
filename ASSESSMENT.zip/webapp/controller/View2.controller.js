sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, JSONModel, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("ASSESSMENTASSESSMENT.controller.View2", {
		onInit: function() {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("View2").attachPatternMatched(this._onObjectMatched, this);
			var Duplicate= new JSONModel();
			this.getView().setModel(Duplicate,"Duplicate");
		},
		_onObjectMatched: function(oEvent) {
			var that=this;
			var FormModel = new JSONModel();
			this.getView().setModel(FormModel, "Model");
			var obj = oEvent.getParameter("arguments").Record;

			var odata = this.getOwnerComponent().getModel();
			// var	url="/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			// 	var odata=sap.ui.model.odata.ODataModel(url,true);
			var ONewFilters = new Filter({
				path: "EmpId",
				operator: FilterOperator.Contains,
				value1: obj
			});

			odata.read("/Employee_DetailsSet", {
				filters: [ONewFilters],
				success: function(data) {
					 //FormModel.setData(data.results[0]);
					that.getView().getModel("Model").setData(data.results[0]);
					that.getView().getModel("Duplicate").setData(JSON.parse(JSON.stringify(data.results[0])));
				}
			});
			var model = new JSONModel({
				editable: false,
				editVsblBtn: true,
				closeVsblBtn: true,
				saveVsblBtn: true,
				cancelvsblbtn: true
			});
			this.getView().setModel(model, "ViewModel");

		},
		onNavButtonPress: function() {
			history.go(-1);
		},
		onEdit: function() {

			this.getView().getModel("ViewModel").setProperty("/editable", true);
			this.getView().getModel("ViewModel").setProperty("/editVsblBtn", false);
			this.getView().getModel("ViewModel").setProperty("/saveVsblBtn", false);
			this.getView().getModel("ViewModel").setProperty("/cancelvsblbtn", false);
			this.getView().getModel("ViewModel").setProperty("/cancelvsblbtn", false);

		},
		onSave: function() {
			var formdata = this.getView().getModel("Model").getData();
			var odata = this.getOwnerComponent().getModel();
			//var	url="/sap/opu/odata/sap/ZHR_EMPLOYEE_DETAIL_SRV/";
			// var odata = new sap.ui.model.odata.ODataModel(url, true);
			odata.update("/Employee_DetailsSet('" + formdata.EmpId + "')", formdata, {
				success: function() {

				},
				error: function() {

				}
			});
		},
		IconTabSelect: function(oEvent) {
			// this.getView().getModel("ViewModel").setProperty("/editVsblBtn", false);
			var keys= oEvent.getParameter("key");
			if (keys === "personal Details") {
				this.getView().getModel("ViewModel").setProperty("/editVsblBtn", true);
			}
			if (keys === "Address Details") {
				this.getView().getModel("ViewModel").setProperty("/editVsblBtn", true);
			}
			if (keys === "Performance") {
				this.getView().getModel("ViewModel").setProperty("/editVsblBtn", false);
			}
			if (keys === "Address Details") {
				this.getView().getModel("ViewModel").setProperty("/editable", false);
			}
		},
		onCancel:function(){
			
		var DuplicatedData=	this.getView().getModel("Duplicate").getData();
			this.getView().getModel("Model").setData(DuplicatedData);
			
		}
		

	});
});